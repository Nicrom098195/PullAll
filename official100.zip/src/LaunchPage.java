import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class LaunchPage implements ActionListener{
 
 JFrame frame = new JFrame();
 JButton play = new JButton("Gioca");
 JButton close = new JButton("Chiudi");
 
 LaunchPage(){
  
  play.setBounds(600,430,200,40);
  play.setFocusable(false);
  play.addActionListener(this);
    
  frame.add(play);

  close.setBounds(600,480,200,40);
  close.setFocusable(false);
  close.addActionListener(this);
  
  frame.add(close);
  
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.setLayout(null);
  frame.setVisible(true);
  frame.setResizable(false);
  frame.setTitle("PullAll release (1.0.0)");
  frame.setSize(1400,900);
  frame.setLocationRelativeTo(null);
  
 }

 @Override
 public void actionPerformed(ActionEvent e) {
  
    if(e.getSource()==play) {
        frame.dispose();
        Game Game = new Game();
    }
    if(e.getSource()==close) {
        frame.dispose();
        frame.setVisible(false);
    }
 }
}
