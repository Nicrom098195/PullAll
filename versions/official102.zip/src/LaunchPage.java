import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class LaunchPage implements ActionListener{
 
 JFrame frame = new JFrame();
 ImageIcon playbtn = new ImageIcon("/opt/PullAll/play.png");
 ImageIcon closebtn = new ImageIcon("/opt/PullAll/close.png");
 JButton play = new JButton("", playbtn);
 JButton close = new JButton("", closebtn);
 Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
 
 LaunchPage(){
  
  play.setBounds(400,430,600,40);
  play.setFocusable(true);
  play.addActionListener(this);
  play.setRolloverIcon(playbtn);
  play.setCursor(cursor);
      
  frame.add(play);

  close.setBounds(400,530,600,40);
  close.setFocusable(true);
  close.addActionListener(this);
  close.setRolloverIcon(closebtn);
  close.setCursor(cursor);
  
  frame.add(close);


  JLabel logo = new JLabel(new ImageIcon("/opt/PullAll/pullall-game.gif"));
  logo.setBounds(0,0,1400,900);

  frame.add(logo);
  
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.setLayout(null);
  frame.setVisible(true);
  frame.setResizable(false);
  frame.setTitle("PullAll snapshot (1.0.2b1)");
  frame.setSize(1400,900);
  frame.setLocationRelativeTo(null);
  
 }

 @Override
 public void actionPerformed(ActionEvent e) {
  
    if(e.getSource()==play) {
        frame.dispose();
        Game Game = new Game();
    }
    if(e.getSource()==close) {
        frame.dispose();
        frame.setVisible(false);
    }
 }
}
