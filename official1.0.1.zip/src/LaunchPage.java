import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class LaunchPage implements ActionListener{
 
 JFrame frame = new JFrame();
 JButton play = new JButton("Gioca");
 JButton close = new JButton("Chiudi");
 JButton stings = new JButton("Impostazioni");
 
 LaunchPage(){
  
  stings.setBounds(600,480,200,40);
  stings.setFocusable(true);
  stings.addActionListener(this);
     
  frame.add(stings);
  
  play.setBounds(600,430,200,40);
  play.setFocusable(true);
  play.addActionListener(this);
      
  frame.add(play);

  close.setBounds(600,530,200,40);
  close.setFocusable(true);
  close.addActionListener(this);
  
  frame.add(close);
  
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.setLayout(null);
  frame.setVisible(true);
  frame.setResizable(false);
  frame.setTitle("PullAll release (1.0.1)");
  frame.setSize(1400,900);
  frame.setLocationRelativeTo(null);
  
 }

 @Override
 public void actionPerformed(ActionEvent e) {
  
    if(e.getSource()==play) {
        frame.dispose();
        Game Game = new Game();
    }
    if(e.getSource()==close) {
        frame.dispose();
        frame.setVisible(false);
    }
    if(e.getSource()==stings) {
        Settings Settings = new Settings();
        frame.setVisible(false);
    }
 }
}
