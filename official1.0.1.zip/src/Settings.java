import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class Settings implements ActionListener{
 
 JFrame frame = new JFrame();
 JButton close = new JButton("Chiudi");
 
 Settings(){

  close.setBounds(600,530,200,40);
  close.setFocusable(true);
  close.addActionListener(this);
  
  frame.add(close);
  
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.setLayout(null);
  frame.setVisible(true);
  frame.setResizable(false);
  frame.setTitle("Settings | PullAll release (1.0.1)");
  frame.setSize(1400,900);
  frame.setLocationRelativeTo(null);
  
 }

 @Override
 public void actionPerformed(ActionEvent e) {
    if(e.getSource()==close) {
        LaunchPage lp = new LaunchPage();
        frame.setVisible(false);
    }
 }
}
