import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class Camera implements KeyListener{
	public double xPos, yPos, xDir, yDir, xPlane, yPlane;
	public boolean Tleft, Tright, left, right, forward, back, run, shift;
	public final double ROTATION_SPEED = .045;
	public int lxpos, lypos;
	public Camera(double x, double y, double xd, double yd, double xp, double yp) {
		xPos = x;
		yPos = y;
		xDir = xd;
		yDir = yd;
		xPlane = xp;
		yPlane = yp;
	}
	double MOVE_SPEED = 0.08;
	public void keyPressed(KeyEvent key) {
		if((key.getKeyCode() == KeyEvent.VK_LEFT))
			Tleft = true;
		if((key.getKeyCode() == KeyEvent.VK_RIGHT))
			Tright = true;
		if((key.getKeyCode() == KeyEvent.VK_W))
			forward = true;
		if((key.getKeyCode() == KeyEvent.VK_S))
			back = true;
		if((key.getKeyCode() == KeyEvent.VK_UP))
			forward = true;
		if((key.getKeyCode() == KeyEvent.VK_DOWN))
			back = true;
		if((key.getKeyCode() == KeyEvent.VK_A))
			left = true;
		if((key.getKeyCode() == KeyEvent.VK_D))
			right = true;
		if((key.getKeyCode() == KeyEvent.VK_CONTROL ))
			run = true;
		if((key.getKeyCode() == KeyEvent.VK_L ))
			System.exit(0);
		if((key.getKeyCode() == KeyEvent.VK_SHIFT ))
			shift = true;
	}
	public void keyReleased(KeyEvent key) {
		if((key.getKeyCode() == KeyEvent.VK_LEFT))
			Tleft = false;
		if((key.getKeyCode() == KeyEvent.VK_RIGHT))
			Tright = false;
		if((key.getKeyCode() == KeyEvent.VK_D))
			right = false;
		if((key.getKeyCode() == KeyEvent.VK_A))
			left = false;
		if((key.getKeyCode() == KeyEvent.VK_W))
			forward = false;
		if((key.getKeyCode() == KeyEvent.VK_UP))
			forward = false;
		if((key.getKeyCode() == KeyEvent.VK_DOWN))
			back = false;
		if((key.getKeyCode() == KeyEvent.VK_S))
			back = false;
		if((key.getKeyCode() == KeyEvent.VK_CONTROL ))
			run = false;
		if((key.getKeyCode() == KeyEvent.VK_SHIFT ))
			shift = false;
	}
	public void update(int[][] map) {
		if(forward) {
			if(run) {
				MOVE_SPEED = 0.17;
			} else {
				MOVE_SPEED = 0.08;
			}
			if(shift) {
				MOVE_SPEED = 0.04;
			} else {
				MOVE_SPEED = 0.08;
			}
			if(map[(int)(xPos + xDir * MOVE_SPEED)][(int)yPos] == 0) {
				xPos+=xDir*MOVE_SPEED;
			}
			if(map[(int)xPos][(int)(yPos + yDir * MOVE_SPEED)] ==0)
				yPos+=yDir*MOVE_SPEED;
			System.out.println("X: " + (int) xPos + ", Y: " + (int) yPos);
		}
		if(back) {
			if(run) {
				MOVE_SPEED = 0.17;
			} else {
				MOVE_SPEED = 0.08;
			}
			if(shift) {
				MOVE_SPEED = 0.04;
			} else {
				MOVE_SPEED = 0.08;
			}
			if(map[(int)(xPos - xDir * MOVE_SPEED)][(int)yPos] == 0)
				xPos-=xDir*MOVE_SPEED;
			if(map[(int)xPos][(int)(yPos - yDir * MOVE_SPEED)]==0)
				yPos-=yDir*MOVE_SPEED;
			System.out.println("X: " + (int) xPos + ", Y: " + (int) yPos);
		}
		if(Tright) {
			double oldxDir=xDir;
			xDir=xDir*Math.cos(-ROTATION_SPEED) - yDir*Math.sin(-ROTATION_SPEED);
			yDir=oldxDir*Math.sin(-ROTATION_SPEED) + yDir*Math.cos(-ROTATION_SPEED);
			double oldxPlane = xPlane;
			xPlane=xPlane*Math.cos(-ROTATION_SPEED) - yPlane*Math.sin(-ROTATION_SPEED);
			yPlane=oldxPlane*Math.sin(-ROTATION_SPEED) + yPlane*Math.cos(-ROTATION_SPEED);
		}
		if(Tleft) {
			double oldxDir=xDir;
			xDir=xDir*Math.cos(ROTATION_SPEED) - yDir*Math.sin(ROTATION_SPEED);
			yDir=oldxDir*Math.sin(ROTATION_SPEED) + yDir*Math.cos(ROTATION_SPEED);
			double oldxPlane = xPlane;
			xPlane=xPlane*Math.cos(ROTATION_SPEED) - yPlane*Math.sin(ROTATION_SPEED);
			yPlane=oldxPlane*Math.sin(ROTATION_SPEED) + yPlane*Math.cos(ROTATION_SPEED);
		}
		if (left) {
			if(run) {
				MOVE_SPEED = 0.17;
			} else {
				MOVE_SPEED = 0.08;
			}
			if(shift) {
				MOVE_SPEED = 0.04;
			} else {
				MOVE_SPEED = 0.08;
			}
			if (map[(int) (xPos)][(int) (yPos + xDir * MOVE_SPEED)] == 0) {
				yPos += xDir * MOVE_SPEED;
			}
			if (map[(int) (xPos - yDir * MOVE_SPEED)][(int) (yPos)] == 0) {
				xPos -= yDir * MOVE_SPEED;
			}
			System.out.println("X: " + (int) xPos + ", Y: " + (int) yPos);
		}
		if (right) {
			if(run) {
				MOVE_SPEED = 0.17;
			} else {
				MOVE_SPEED = 0.08;
			}
			if(shift) {
				MOVE_SPEED = 0.04;
			} else {
				MOVE_SPEED = 0.08;
			}
			if (map[(int) (xPos)][(int) (yPos - xDir * MOVE_SPEED)] == 0) {
				yPos -= xDir * MOVE_SPEED;
			}
			if (map[(int) (xPos + yDir * MOVE_SPEED)][(int) (yPos)] == 0) {
				xPos += yDir * MOVE_SPEED;
			}
			System.out.println("X: " + (int) xPos + ", Y: " + (int) yPos);
		}
	}
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
